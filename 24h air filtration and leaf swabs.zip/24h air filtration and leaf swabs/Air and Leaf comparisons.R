#Analyses of Vertebrate communities detected with vaying air filtration times
#Required Packges
library(vegan)
library(ggfortify)
library(devtools)
library(pairwiseAdonis)
library(viridis)
library(ggplot2)
library(ape)
library(dplyr)
library(hagis)
library(ggplot2)

#Bring in the datasheet
Tab <- read.csv2("Air_Leaf_OTU.csv", row.names = 1, check.names = FALSE)

Tab2 <- Tab[5:71]
Meta <- Tab[1:4]
dis <- vegdist(Tab2, method = "jaccard")

#PCOA
princoor <- pcoa(dis) 
Axis1.percent <-princoor$values$Relative_eig[[1]] * 100
Axis2.percent <-princoor$values$Relative_eig[[2]] * 100

Axis1.percent
Axis2.percent
princoor.pathotype.data <-data.frame(Sample = as.integer(rownames(princoor$vectors)),X = princoor$vectors[, 1], Y = princoor$vectors[, 2])

#download the coordinates and incorperte metadata to the cordinates
write.csv2(princoor.pathotype.data, file = "Air_Leaf_Cord.csv")

#Bring in the stat document with the coordinates
Data <- read.csv2("Air_Leaf_Cord.csv", row.names = 1, check.names = FALSE)

ggplot(data = Data, aes(x = X, y = Y)) + geom_point(size=7, aes(colour = Type, shape = Day))+ scale_color_manual(values=c("#a3a3e6" ,"#458f25")) + theme_classic() + scale_shape_manual(values=c(16, 17, 15, 18)) + stat_ellipse(aes(group = Type, col = Type), linetype = 2, type = "t", level = 0.80)


### Adonis tests - PERMANOVA (we will do this on the same distance matrix made for PCOAs: dis output from the vegdist function #line 19)

#set the "by" parameter to "margin".
adonis2(formula = dis~ Type + Day, data = Meta, by = "margin", permutations = 10000, strata = Meta$Sam_point)

#pair-wise differences with benferroni corrections
pairwise.adonis(dis, Meta$SampleSite, sim.function = "jaccard",
                sim.method = "jaccard", p.adjust.m = "bonferroni", reduce = NULL,
                perm = 10000)

### Generating box plots visualise the detected vertebrate richness
Rich <- read.csv2("Richness_Air_Leaf.csv", row.names = 1, check.names = FALSE)

ggplot(Rich, aes(x=Type, y=Vert_Rich)) + geom_boxplot(aes(fill = Event))+ theme_classic()+ scale_fill_manual(values=c("#a3a3e6" ,"#458f25"))
ggplot(Rich, aes(x=Day, y=Vert_Rich)) + geom_boxplot(aes(fill = Type),outlier.shape = NA)+ theme_classic() + scale_fill_manual(values=c("#a3a3e6" ,"#458f25")) + geom_jitter(aes(color = Type), size = 3) + scale_color_manual(values=c("#a3a3e6" ,"#458f25"))

ggplot(Rich, aes(x=Time, y=Bird_Rich)) + geom_boxplot(aes(fill = Event))+ theme_classic()+ scale_fill_manual(values=c("#a3a3e6" , "#2d2dbd","#000075"))
ggplot(Rich, aes(x=Day, y=Bird_Rich)) + geom_boxplot(aes(fill = Type), outlier.shape = NA)+ theme_classic() + scale_fill_manual(values=c("#a3a3e6" ,"#458f25")) + geom_jitter(aes(color = Type), size = 3) + scale_color_manual(values=c("#a3a3e6" ,"#458f25"))

ggplot(Rich, aes(x=Time, y=Mam_Rich)) + geom_boxplot(aes(fill = Event))+ theme_classic()+ scale_fill_manual(values=c("#a3a3e6" , "#2d2dbd","#000075"))
ggplot(Rich, aes(x=Day, y=Mam_Rich)) + geom_boxplot(aes(fill = Type), outlier.shape = NA)+ theme_classic() + scale_fill_manual(values=c("#a3a3e6" ,"#458f25")) + geom_jitter(aes(color = Type), size = 3) + scale_color_manual(values=c("#a3a3e6" ,"#458f25"))


###Upset plots (for upset pots we need to create an input file that support the package based on precence absence of taxa across sampling times (Upset_Leaf.csv))
library(UpSetR)
Up <- read.csv2("Upset_Leaf.csv", row.names = 1, check.names = FALSE)
Up <- as.data.frame(Up)
upset(Up, sets = c("24h","Leaf"), sets.bar.color = "#56B4E9",
      order.by = "degree", empty.intersections = "off", keep.order = TRUE)

#LMM with a random effect (evaluating the effect of sample type and sample day on vertebrate richness)
library(lmerTest)
model1 <- lmer(Vert_Rich ~  Type + Day + (1|Sam_point) , Rich)
model2 <- lmer(Bird_Rich ~  Type + Day + (1|Sam_point) , Rich)
model3 <- lmer(Mam_Rich ~  Type + Day + (1|Sam_point) , Rich)

summary(model1)
anova(model1)
anova(model2)
anova(model3)

#conduct pairwise tests with emmeans package
library(emmeans)  
Pair <- pairs(emmeans(model3,  ~Time))
summary(Pair)

### Extrapolation and rarefaction curves with iNEXT package (Need to create a presence/absence table of the taxa)
library(iNEXT)
library(ggiNEXT)

Data <- read.csv2("Air_Leaf_iNext.csv", row.names = 1, check.names = FALSE)
Mat_A<- as.data.frame((Data))
Air<- Mat_A [1:67, 1:40]
Air <- as.matrix((Air > 0) + 0)

Leaf<- Mat_A [1:67, 41:70]
Leaf <- as.matrix((Leaf > 0) + 0)

data.list <- list(Air, Leaf)
names(data.list) <- c("Air", "Leaf")

out.raw <- iNEXT(data.list, q=0, datatype="incidence_raw")

ggiNEXT(out.raw, type=1, grey=TRUE)+ scale_fill_manual(values=c("#a3a3e6" ,"#458f25")) + scale_color_manual(values=c("#a3a3e6" ,"#458f25")) + theme_classic()

