#Analyses of Vertebrate communities detected with varying air filtration times
#Required Packages
library(vegan)
library(ggfortify)
library(devtools)
library(pairwiseAdonis)
library(viridis)
library(ggplot2)
library(ape)
library(dplyr)
library(hagis)
library(ggplot2)

#Bring in the datasheet (concatenated vertebrate dataset). Note: for individuals datasets (BirT and 16Smam) we used the same code.
Tab <- read.csv2("Air_OTU.csv", row.names = 1, check.names = FALSE)

Tab2 <- Tab[5:77]
Meta <- Tab[1:4]
dis <- vegdist(Tab2, method = "jaccard")

#PCOA
princoor <- pcoa(dis) 
Axis1.percent <-princoor$values$Relative_eig[[1]] * 100
Axis2.percent <-princoor$values$Relative_eig[[2]] * 100

Axis1.percent
Axis2.percent
princoor.pathotype.data <-data.frame(Sample = as.integer(rownames(princoor$vectors)),X = princoor$vectors[, 1], Y = princoor$vectors[, 2])

#download the coordinates and incorperte metadata to the cordinates
write.csv2(princoor.pathotype.data, file = "Air_PCA_Cord.csv")

#Bring in the stat document with the coordinates
Data <- read.csv2("Air_PCA_Cord.csv", row.names = 1, check.names = FALSE)
Data$Time <- factor(Data$Time, levels = c("24h", "48h", "96h"))

ggplot(data = Data, aes(x = X, y = Y)) + geom_point(size=7, aes(colour = Time, shape = Event))+ scale_color_manual(values=c("#a3a3e6" , "#2d2dbd","#000075")) + theme_classic() + scale_shape_manual(values=c(16, 17, 15, 18)) + stat_ellipse(aes(group = Time, col = Time), linetype = 2, type = "t", level = 0.80)

ggplot(data = Data, aes(x = X, y = Y)) + geom_point(size=7, aes(colour = Time))+ scale_color_manual(values=c("#a3a3e6" , "#5b5bf5","#000075")) + theme_classic() + scale_shape_manual(values=c(16, 17, 15, 18)) + stat_ellipse(aes(group = Time, col = Time), linetype = 2, type = "t", level = 0.80)

####Adonis tests - PERMANOVA (we will do this on the same distance matrix made for PCOAs: dis output from the vegdist function #line 19)

#set the "by" parameter to "margin".
adonis2(formula = dis~ Time + Sam_point, data = Meta, by = "margin", permutations = 10000)

#pair-wise differences with benferroni corrections

pairwise.adonis(dis, Meta$Time, sim.function = "jaccard",
                sim.method = "jaccard", p.adjust.m = "bonferroni", reduce = NULL,
                perm = 10000)

####Generating box plots visualise the detected vertebrate richness
Rich <- read.csv2("Richness_Air.csv", row.names = 1, check.names = FALSE)
Rich$Time <- factor(Rich$Time, levels = c("24h", "48h", "96h"))

ggplot(Rich, aes(x=Time, y=Vert_Rich)) + geom_boxplot(aes(fill = Event))+ theme_classic()+ scale_fill_manual(values=c("#a3a3e6" , "#2d2dbd","#000075"))
ggplot(Rich, aes(x=Time, y=Vert_Rich)) + geom_boxplot(aes(fill = Time))+ theme_classic() + scale_fill_manual(values=c("#a3a3e6" , "#5b5bf5","#000075")) + geom_jitter(aes(), col = "#63636e", size = 3) + scale_shape_manual(values=c(16, 17, 15, 18))

ggplot(Rich, aes(x=Time, y=Bird_Rich)) + geom_boxplot(aes(fill = Event))+ theme_classic()+ scale_fill_manual(values=c("#a3a3e6" , "#2d2dbd","#000075"))
ggplot(Rich, aes(x=Time, y=Bird_Rich)) + geom_boxplot(aes(fill = Time))+ theme_classic() + scale_fill_manual(values=c("#a3a3e6" , "#5b5bf5","#000075")) + geom_jitter(aes(), col = "#63636e", size = 3)

ggplot(Rich, aes(x=Time, y=Mam_Rich)) + geom_boxplot(aes(fill = Event))+ theme_classic()+ scale_fill_manual(values=c("#a3a3e6" , "#2d2dbd","#000075"))
ggplot(Rich, aes(x=Time, y=Mam_Rich)) + geom_boxplot(aes(fill = Time), outlier.shape = NA)+ theme_classic() + scale_fill_manual(values=c("#a3a3e6" , "#5b5bf5","#000075")) + geom_jitter(aes(), col = "#63636e", size = 3)


####Upset plots (for upset pots we need to create an input file that support the package based on precence absence of taxa across sampling times (Upset.csv))
library(UpSetR)
Up <- read.csv2("Upset.csv", row.names = 1, check.names = FALSE)
Up <- as.data.frame(Up)
upset(Up, sets = c("24h","48h","96h" ), sets.bar.color = "#56B4E9",
      order.by = "degree", empty.intersections = "off", keep.order = TRUE)

#LMM with a random effect (evaluating the effect of sampling time on vertebrate richness)
library(lmerTest)
model1 <- lmer(Vert_Rich ~  Time + (1|Sam_point) , Rich)
model2 <- lmer(Bird_Rich ~  Time + (1|Sam_point) , Rich)
model3 <- lmer(Mam_Rich ~  Time + (1|Sam_point) , Rich)

summary(model1)
anova(model1)
anova(model2)
anova(model3)

#conduct pairwise tests with emmeans package
library(emmeans)  
Pair <- pairs(emmeans(model3,  ~Time))
summary(Pair)

#### Extraplotaion and reafaction curves with iNEXT package (Need to create a presence/absence table of the taxa)
library(iNEXT)
library(ggiNEXT)

Data <- read.csv2("Air_iNext.csv", row.names = 1, check.names = FALSE)
Mat_A<- as.data.frame((Data))
h24<- Mat_A [1:73, 1:40]
h24 <- as.matrix((h24 > 0) + 0)

h48<- Mat_A [1:73, 41:60]
h48 <- as.matrix((h48 > 0) + 0)

h96<- Mat_A [1:73, 61:70]
h96 <- as.matrix((h96 > 0) + 0)

data.list <- list(h24, h48, h72)
names(data.list) <- c("24h", "48h", "96h")

out.raw <- iNEXT(data.list, q=0, datatype="incidence_raw")

ggiNEXT(out.raw, type=1, grey=TRUE)+ scale_fill_manual(values=c("#a3a3e6" , "#5b5bf5","#000075")) + scale_color_manual(values=c("#a3a3e6" , "#5b5bf5","#000075")) + theme_classic()


####Nestedness analyses across airsampling times

library(betapart)
otu_Air <- as(Tab2, "matrix")

#samples need to be rows and taxa need to be columns
#For incidence-based analysis: convert abundances to 0 or 1
pres_abs_Air <- ifelse(otu_Air > 0, 1, 0)
beta_core_Air <- betapart.core(pres_abs_Air)

#Calculate pairwise dissimilarities (total, turnover, nestedness components)
#Using the Sørensen index family as an example (incidence-based)
pairwise_beta_Air <- beta.pair(beta_core_Air, index.family = "sorensen")

#pairwise_beta$beta.sne (nestedness component)

Nest <- as.matrix(pairwise_beta_Air$beta.sne)
write.csv2(Nest, "Air_Nestedness.csv")

#Nestedness analyses and figures
#Based on the "Air_Nestedness.csv" file I generated a datasheet seperating the individual comparisons (this can be found in "Nestedness_Final.csv")
Nested <-read.csv2("Nestedness_Final.csv", row.names = 1, check.names = FALSE)

ggplot(Nested, aes(x=Comparison, y=Nest)) + geom_boxplot(aes(fill = Site))+ theme_classic()+ scale_colour_viridis(values=c())

#LLM
model4 <- lmer(Nest ~  Comparison + (1|Site) , Nested)
anova(model4)

#Pairwise differences
library(emmeans)  
Pair <- pairs(emmeans(model4,  ~Comparison))
summary(Pair)

####Mantel tests
library(sf)

#Bring in the coordinate
Cord <-read.csv2("Air_Coordidnations.csv", row.names = 1, check.names = FALSE)

species_sf <- st_as_sf(Cord, coords = c("longitude", "latitude"), crs = 4326)
Air_m <- st_distance(species_sf)

write.csv2(as.matrix(Air_m), file = "Air_cord_dist.csv")

# Bring in the OTU tables (individual one for each of the sampling time and sampling event)
OTU_24_D1 <-read.csv2("24h_D1.csv", row.names = 1, check.names = FALSE)
OTU_24_D2 <-read.csv2("24h_D2.csv", row.names = 1, check.names = FALSE)
OTU_24_D3 <-read.csv2("24h_D3.csv", row.names = 1, check.names = FALSE)
OTU_24_D4 <-read.csv2("24h_D4.csv", row.names = 1, check.names = FALSE)
OTU_48_D2 <-read.csv2("48h_D2.csv", row.names = 1, check.names = FALSE)
OTU_48_D4 <-read.csv2("48h_D4.csv", row.names = 1, check.names = FALSE)
OTU_96_D4 <-read.csv2("96h_D4.csv", row.names = 1, check.names = FALSE)

#Calculate community distances between samples
h24_D1 <- vegdist(OTU_24_D1, method = "jaccard")
h24_D2 <- vegdist(OTU_24_D2, method = "jaccard")
h24_D3 <- vegdist(OTU_24_D3, method = "jaccard")
h24_D4 <- vegdist(OTU_24_D4, method = "jaccard")
h48_D2 <- vegdist(OTU_48_D2, method = "jaccard")
h48_D4 <- vegdist(OTU_48_D4, method = "jaccard")
h96_D4 <- vegdist(OTU_96_D4, method = "jaccard")

#running the mantel test
Man <- mantel(h96_D4, Air_m, method="pearson", permutations=10000, strata = NULL,na.rm = FALSE)
Man
